# User-opt-in audit configuration helper. Only launch if you explicitly want persistent OS audit changes.
$ErrorActionPreference = 'Stop'
$guid = '{0CCE922B-69AE-11D9-BED3-505054503030}'
$key = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit'
$valueName = 'ProcessCreationIncludeCmdLine_Enabled'
$root = Join-Path $env:LOCALAPPDATA 'CMD_Flash_Detector'
$backup = Join-Path $root 'PreciseAuditOriginal.json'
New-Item -ItemType Directory -Force -Path $root | Out-Null
function Get-LocalSuccess {
    $lines = @( & auditpol.exe /get ('/subcategory:' + $guid) /r 2>&1 )
    if ($LASTEXITCODE -ne 0) { throw "auditpol read failed: $($lines -join ' ')" }
    $line = @($lines | Where-Object { $_ -match '0CCE922B-69AE-11D9-BED3-505054503030' })
    if ($line.Count -ne 1) { throw 'Cannot identify the audit subcategory. No changes made.' }
    $csv = @( $lines | ConvertFrom-Csv )
    $item = @($csv | Where-Object { (($_.PSObject.Properties.Value) -join ' ') -match '0CCE922B-69AE-11D9-BED3-505054503030' })
    if ($item.Count -ne 1) { throw 'Cannot parse auditpol /r. No changes made.' }
    $cols = @($item[0].PSObject.Properties.Value)
    if ($cols.Count -lt 5) { throw 'Unexpected auditpol result. No changes made.' }
    $setting = [string]$cols[4]
    if ($setting -match '성공|Success') { return $true }
    if ($setting -match '감사 안 함|No Auditing|없음|None|실패|Failure') { return $false }
    throw "Unknown localized auditpol state: $setting. No changes made."
}
try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $isAdmin = ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) { throw 'Administrator rights are required.' }
    Write-Host 'Windows 4688 process auditing can record commands containing private information.' -ForegroundColor Yellow
    Write-Host 'This changes persistent Windows audit policy. Run RESTORE_PRECISE_AUDIT_ADMIN.cmd to revert.' -ForegroundColor Yellow
    $ok = Read-Host 'Type YES to enable process creation auditing and command lines'
    if ($ok -ne 'YES') { Write-Host 'Cancelled; no changes.'; exit 0 }
    if (Test-Path -LiteralPath $backup) {
        throw "Existing backup found: $backup. Restore the prior settings before enabling again."
    }
    $successEnabled = Get-LocalSuccess
    $originalProp = Get-ItemProperty -Path $key -Name $valueName -ErrorAction SilentlyContinue
    $originalPresent = $null -ne $originalProp
    $originalValue = if ($originalPresent) { [int]$originalProp.$valueName } else { 0 }
    $save = [pscustomobject]@{
        Created=(Get-Date).ToString('o'); Computer=$env:COMPUTERNAME
        OriginalSuccessEnabled=[bool]$successEnabled
        OriginalCmdLinePresent=[bool]$originalPresent
        OriginalCmdLineValue=$originalValue
    }
    $save | ConvertTo-Json | Set-Content -LiteralPath $backup -Encoding UTF8
    $result = @( & auditpol.exe /set ('/subcategory:' + $guid) /success:enable 2>&1 )
    if ($LASTEXITCODE -ne 0) { throw "auditpol change failed: $($result -join ' ')" }
    if (-not (Test-Path -LiteralPath $key)) { New-Item -Path $key -Force | Out-Null }
    New-ItemProperty -Path $key -Name $valueName -Value 1 -PropertyType DWord -Force | Out-Null
    if (-not (Get-LocalSuccess)) { throw 'Verification: process auditing did not become enabled.' }
    Write-Host 'ENABLED: Security 4688 process creation auditing and command lines.' -ForegroundColor Green
    Write-Host 'Close/reopen the detector as Administrator, run the ultra-short test, then inspect 4688.'
    Write-Host "Original setting saved at: $backup"
} catch { Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }

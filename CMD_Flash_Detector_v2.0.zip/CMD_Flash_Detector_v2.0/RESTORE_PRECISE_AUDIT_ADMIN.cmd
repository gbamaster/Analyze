@echo off
wscript.exe "%~dp0ELEVATE.vbs" restore

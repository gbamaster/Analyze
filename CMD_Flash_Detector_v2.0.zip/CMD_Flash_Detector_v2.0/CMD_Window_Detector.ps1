﻿# CMD Flash Detector v2.0 - Windows PowerShell 5.1 / Windows 10, 11
# Local-only monitor. No network, no service, no persistence or policy changes.
# WARNING: logged command lines may contain tokens, private paths, or credentials.
param([switch]$ForceSnapshot)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:root = Join-Path $env:LOCALAPPDATA 'CMD_Flash_Detector'
$script:logDir = Join-Path $script:root 'Logs'
$script:started = Get-Date
try { New-Item -Path $script:logDir -ItemType Directory -Force | Out-Null }
catch {
    $script:root = Join-Path $env:TEMP 'CMD_Flash_Detector'
    $script:logDir = Join-Path $script:root 'Logs'
    New-Item -Path $script:logDir -ItemType Directory -Force | Out-Null
}
$script:jsonFile = Join-Path $script:logDir ("capture_{0}.jsonl" -f $script:started.ToString('yyyyMMdd_HHmmss'))
$script:csvFile = Join-Path $script:logDir ("capture_{0}.csv" -f $script:started.ToString('yyyyMMdd_HHmmss'))
$script:allQueue = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
$script:hitQueue = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
$script:records = New-Object System.Collections.ArrayList
$script:recent = New-Object System.Collections.ArrayList
$script:taskRecords = New-Object System.Collections.ArrayList
$script:contextRecords = New-Object System.Collections.ArrayList
$script:subscriptions = New-Object System.Collections.ArrayList
$script:watchers = New-Object System.Collections.ArrayList
$script:running = $false
$script:monitorInfo = ''
$script:lastAction = ''
$script:nativeMonitor = $null
$script:windowMonitor = $null
$script:windowState = '창 감시: 대기'
$script:auditState = '4688 확인 전'
$script:nativeInterval = 60
$script:uiErrorFile = Join-Path $script:logDir ("ui_errors_{0}.txt" -f $script:started.ToString('yyyyMMdd_HHmmss'))
$script:uiErrorCount = 0
$script:lastUiError = ''
$script:lastUiErrorTime = [datetime]::MinValue
$script:targetRegex = '^(cmd|powershell|pwsh|conhost|openconsole|wt|windowsterminal|wscript|cscript|mshta|taskeng|schtasks|python|pythonw|bash|wsl|sdbinst|rundll32|regsvr32|msiexec)\.exe$'

function Is-Candidate([string]$name) {
    if (-not $name) { return $false }
    return ([System.IO.Path]::GetFileName($name) -match $script:targetRegex)
}

function Save-Raw($ev) {
    try {
        $serial = [pscustomobject]@{
            time = ([datetime]$ev.Time).ToString('o')
            source = [string]$ev.Source
            process = [string]$ev.Name
            pid = [int]$ev.ProcId
            parent_pid = [int]$ev.ParentId
            executable = [string]$ev.Path
            command_line = [string]$ev.Command
            parent_executable = [string]$ev.ParentPath
            parent_command_line = [string]$ev.ParentCommand
            task = [string]$ev.TaskName
            window_title = [string]$ev.WindowTitle
            window_class = [string]$ev.WindowClass
            window_handle = [long]$ev.WindowHandle
            window_action = [string]$ev.WindowAction
            window_duration_ms = [int]$ev.WindowDurationMs
        }
        $line = $serial | ConvertTo-Json -Compress -Depth 4
        [System.IO.File]::AppendAllText($script:jsonFile, "$line`r`n", [System.Text.UTF8Encoding]::new($true))
    } catch {
        $script:monitorInfo = '로그 쓰기 실패: ' + $_.Exception.Message
    }
}

function Export-Data {
    try {
        if ($script:records.Count -eq 0) {
            [System.IO.File]::WriteAllText($script:csvFile, 'Time,Name,PID,ParentPID,Executable,CommandLine,ParentExecutable,ParentCommandLine,ScheduledTask,WindowTitle,WindowClass,WindowHandle,WindowAction,WindowDurationMs,Sources' + "`r`n", [System.Text.UTF8Encoding]::new($true))
            return $true
        }
        $out = foreach ($r in $script:records) {
            [pscustomobject]@{
                Time = $r.Time.ToString('yyyy-MM-dd HH:mm:ss.fff')
                Name = $r.Name
                PID = $r.ProcId
                ParentPID = $r.ParentId
                Executable = $r.Path
                CommandLine = $r.Command
                ParentExecutable = $r.ParentPath
                ParentCommandLine = $r.ParentCommand
                ScheduledTask = $r.TaskName
                WindowTitle = $r.WindowTitle
                WindowClass = $r.WindowClass
                WindowHandle = $r.WindowHandle
                WindowAction = $r.WindowAction
                WindowDurationMs = $r.WindowDurationMs
                Sources = $r.Sources
            }
        }
        if ($null -eq $out) { $out = @() }
        @($out) | Export-Csv -LiteralPath $script:csvFile -NoTypeInformation -Encoding UTF8
        return $true
    } catch {
        [System.Windows.Forms.MessageBox]::Show("CSV 저장 실패: $($_.Exception.Message)", '감지기') | Out-Null
        return $false
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'CMD 순간 실행 감지기 2.0 - 프로세스 + 순간 창 감시'
$form.Size = New-Object System.Drawing.Size(1420, 850)
$form.MinimumSize = New-Object System.Drawing.Size(900, 610)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Malgun Gothic', 9)
$form.BackColor = [System.Drawing.Color]::FromArgb(246, 248, 252)

$top = New-Object System.Windows.Forms.Panel
$top.Dock = 'Top'
$top.Height = 164
$form.Controls.Add($top)

function New-Button([string]$label, [int]$x, [int]$w) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $label
    $b.Size = New-Object System.Drawing.Size($w, 34)
    $b.Location = New-Object System.Drawing.Point($x, 12)
    $b.FlatStyle = 'System'
    $top.Controls.Add($b)
    return $b
}
$btnStart = New-Button '감시 시작' 14 148
$btnStop = New-Button '감시 중지' 172 104
$btnTest = New-Button 'CMD 실행 테스트' 286 138
$btnExport = New-Button 'CSV 저장' 434 98
$btnFolder = New-Button '기록 폴더 열기' 542 134
$btnCopy = New-Button '선택 내용 복사' 686 127
$btnGuide = New-Button '정밀 기록 안내' 823 127
$btnCopyStatus = New-Button '상태 복사' 963 101
$btnTestWindow = New-Button '짧은 창 테스트' 1074 124

$notice = New-Object System.Windows.Forms.Label
$notice.Location = New-Object System.Drawing.Point(15, 54)
$notice.Size = New-Object System.Drawing.Size(1130, 23)
$notice.Anchor = 'Top,Left,Right'
$notice.Text = '기본: 프로세스 + 실제 창 표시/숨김 + 예약 작업 + 서비스 이벤트. 정밀: 관리자 권한 및 4688 프로세스 생성 감사 필요.'
$top.Controls.Add($notice)

$status = New-Object System.Windows.Forms.Label
$status.Location = New-Object System.Drawing.Point(15, 78)
$status.Size = New-Object System.Drawing.Size(1280, 42)
$status.Anchor = 'Top,Left,Right'
$status.Text = '준비 중...'
$top.Controls.Add($status)

$btnPrecise = New-Button '정밀 감사 설정 안내' 14 178
$btnPrecise.Location = New-Object System.Drawing.Point(14, 118)
$btnProbe = New-Button '감시 상태 진단' 204 146
$btnProbe.Location = New-Object System.Drawing.Point(204, 118)
$notice2 = New-Object System.Windows.Forms.Label
$notice2.Location = New-Object System.Drawing.Point(362, 125)
$notice2.Size = New-Object System.Drawing.Size(930, 22)
$notice2.Text = '4688/Sysmon 없이 60ms 스냅샷만 사용할 경우 극히 짧은 실행은 누락될 수 있습니다.'
$top.Controls.Add($notice2)

$split = New-Object System.Windows.Forms.SplitContainer
$split.Dock = 'Fill'
$split.Orientation = 'Horizontal'
$split.Size = New-Object System.Drawing.Size(1150, 640)
$split.SplitterDistance = 410
$split.Panel1MinSize = 180
$split.Panel2MinSize = 145
$form.Controls.Add($split)
$top.BringToFront()

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock = 'Fill'
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.ReadOnly = $true
$grid.RowHeadersVisible = $false
$grid.MultiSelect = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.AutoSizeColumnsMode = 'None'
$grid.BackgroundColor = [System.Drawing.Color]::White
$grid.AutoSizeRowsMode = 'None'
$grid.RowTemplate.Height = 27
$grid.Columns.Add('time', '실행 시각') | Out-Null
$grid.Columns.Add('name', '프로세스') | Out-Null
$grid.Columns.Add('window', '창 제목 / 종류') | Out-Null
$grid.Columns.Add('pid', 'PID') | Out-Null
$grid.Columns.Add('parent', '부모 프로그램') | Out-Null
$grid.Columns.Add('task', '예약 작업') | Out-Null
$grid.Columns.Add('source', '확인 출처') | Out-Null
$grid.Columns['time'].Width = 158
$grid.Columns['name'].Width = 150
$grid.Columns['window'].Width = 260
$grid.Columns['pid'].Width = 75
$grid.Columns['parent'].Width = 220
$grid.Columns['task'].Width = 180
$grid.Columns['source'].Width = 135
# Prevent user sorting from conflicting with newest-first row insertion.
foreach ($column in $grid.Columns) {
    $column.SortMode = [System.Windows.Forms.DataGridViewColumnSortMode]::NotSortable
}
$split.Panel1.Controls.Add($grid)

$detail = New-Object System.Windows.Forms.TextBox
$detail.Dock = 'Fill'
$detail.Multiline = $true
$detail.ReadOnly = $true
$detail.ScrollBars = 'Both'
$detail.WordWrap = $false
$detail.Font = New-Object System.Drawing.Font('Consolas', 10)
$detail.BackColor = [System.Drawing.Color]::White
$detail.Text = "감지를 시작하면 기록이 표시됩니다.`r`n프로세스가 사라져도 기록은 남습니다.`r`n`r`n로그 위치: $script:logDir"
$split.Panel2.Controls.Add($detail)

function Write-UiError([string]$where, $errorRecord) {
    # Keep UI callback exceptions diagnosable without showing repeated .NET JIT dialogs.
    try {
        $message = [string]$errorRecord.Exception.Message
        $summary = "$where : $message"
        $script:uiErrorCount++
        $now = Get-Date
        if (($summary -ne $script:lastUiError) -or
            (($now - $script:lastUiErrorTime).TotalSeconds -ge 30)) {
            $script:lastUiError = $summary
            $script:lastUiErrorTime = $now
            $details = "[{0}] {1}`r`n{2}`r`n" -f $now.ToString('o'), $summary, ($errorRecord | Out-String)
            [System.IO.File]::AppendAllText($script:uiErrorFile, $details, [System.Text.UTF8Encoding]::new($true))
        }
        $status.Text = "감시 UI 오류 (로그 저장): $summary"
    } catch {
        # Diagnostic logging must not itself break the WinForms callback.
    }
}

function Refresh-Detail {
    if ($grid.SelectedRows.Count -eq 0) { return }
    $r = $grid.SelectedRows[0].Tag
    if ($null -eq $r) { return }
    $near = @($script:recent | Where-Object {
        ([Math]::Abs(($_.Time - $r.Time).TotalSeconds) -le 2.0) -and
        ($_.ProcId -ne $r.ProcId)
    } | Select-Object -First 12)
    $neighbors = if ($near.Count) {
        ($near | ForEach-Object { '  ' + $_.Time.ToString('HH:mm:ss.fff') + '  ' + $_.Name + ' (PID ' + $_.ProcId + ', PPID ' + $_.ParentId + ')' }) -join "`r`n"
    } else { '  (기록된 관련 시작 이벤트 없음)' }
    $nearContext = @($script:contextRecords | Where-Object {
        [Math]::Abs(($_.Time - $r.Time).TotalSeconds) -le 3 -and $r.ProcId -ne 0
    } | Select-Object -Last 10)
    $contextStr = if ($nearContext.Count) {
        ($nearContext | ForEach-Object { '  ' + $_.Time.ToString('HH:mm:ss.fff') + '  ' + $_.Source + '  ' + $_.TaskName + '  ' + $_.Path }) -join "`r`n"
    } else { '  (인접한 서비스·작업 기록 없음)' }
    $detail.Text = @"
시간: $($r.Time.ToString('yyyy-MM-dd HH:mm:ss.fff'))
프로세스: $($r.Name)
PID: $($r.ProcId)
실행 파일: $(if ($r.Path) {$r.Path} else {'종료되어 경로 확인 불가'})
명령줄: $(if ($r.Command) {$r.Command} else {'미확보 - 빠른 종료 또는 감사 미설정'})
부모 PID: $($r.ParentId)
부모 실행 파일: $(if ($r.ParentPath) {$r.ParentPath} else {'확인 불가'})
부모 명령줄: $(if ($r.ParentCommand) {$r.ParentCommand} else {'확인 불가'})
예약 작업 이름: $(if ($r.TaskName) {$r.TaskName} else {'연결된 예약 작업 확인 안 됨'})
증거 출처: $($r.Sources)
창 제목: $(if ($r.WindowTitle) {$r.WindowTitle} else {'확인되지 않음'})
창 종류(Win32 Class): $(if ($r.WindowClass) {$r.WindowClass} else {'확인되지 않음'})
창 핸들: $($r.WindowHandle)
창 상태: $(if ($r.WindowAction -eq 'HIDE') {'사라짐'} elseif ($r.WindowAction -eq 'SHOW') {'표시 감지'} elseif ($r.WindowAction -eq 'CREATE') {'창 생성 감지 (표시 여부 불명)'} else {'창 이벤트 없음'})
표시 지속시간: $(if ($r.WindowAction -eq 'HIDE' -and $r.WindowDurationMs -ge 0) {[string]$r.WindowDurationMs + ' ms (창 이벤트 관측 기준)'} else {'확인 불가'})

같은 시각(+-2초) 시작된 다른 프로세스 - 인과 관계는 미확정:
$neighbors

같은 시각(+-3초)의 서비스/예약 작업 - 원인으로 확정하지 않음:
$contextStr

참고: PID는 재사용됩니다. 예약 작업 이름은 PID와 시작 시각을 함께 대조했습니다.
명령줄에는 개인정보가 들어갈 수 있으니 공유 전 확인하세요.
"@
}
$grid.Add_SelectionChanged({
    try { Refresh-Detail }
    catch { Write-UiError 'SelectionChanged' $_ }
})

function Update-Row($r) {
    $row = $r.Row
    if ($null -eq $row) { return }
    $windowLabel = if ($r.WindowTitle) { $r.WindowTitle } elseif ($r.WindowClass) { '[' + $r.WindowClass + ']' } else { '' }
    if ($r.WindowAction -eq 'HIDE' -and $r.WindowDurationMs -ge 0) {
        $windowLabel += ' (' + [string]$r.WindowDurationMs + 'ms)'
    }
    $row.Cells[0].Value = $r.Time.ToString('HH:mm:ss.fff')
    $row.Cells[1].Value = $r.Name
    $row.Cells[2].Value = $windowLabel
    $row.Cells[3].Value = [string]$r.ProcId
    $row.Cells[4].Value = [string]$r.ParentPath
    $row.Cells[5].Value = [string]$r.TaskName
    $row.Cells[6].Value = [string]$r.Sources
}

function Apply-Event($ev) {
    # With native snapshots, get a best-effort command line while the process
    # is still running. Failures do not disable the native capture.
    if ($ev.Source -like '스냅샷*' -and -not $ev.Command) {
        try {
            $child = Get-CimInstance -ClassName Win32_Process -Filter ("ProcessId={0}" -f [int]$ev.ProcId) -ErrorAction Stop
            if ($null -ne $child) {
                $ctime = [datetime]$child.CreationDate
                if ($ctime -le ([datetime]$ev.Time).AddSeconds(2) -and
                    $ctime -ge ([datetime]$ev.Time).AddSeconds(-10)) {
                    $ev.Command = [string]$child.CommandLine
                    if (-not $ev.Path) { $ev.Path = [string]$child.ExecutablePath }
                }
            }
        } catch { }
    }
    if ([string]$ev.Source -like '서비스 *' -or [string]$ev.Source -like '예약 작업 *' -or [string]$ev.Source -like '진단: *') {
        Save-Raw $ev
        [void]$script:contextRecords.Add($ev)
        while ($script:contextRecords.Count -gt 500) { $script:contextRecords.RemoveAt(0) }
        # Distinct activity event with PID 0. Do not attribute to adjacent processes.
        $r = [pscustomobject]@{
            Time=[datetime]$ev.Time; Name=[string]$ev.Name; ProcId=0; ParentId=0
            Path=[string]$ev.Path; Command=''; ParentPath=''; ParentCommand=''
            TaskName=[string]$ev.TaskName; Sources=[string]$ev.Source
            WindowTitle=[string]$ev.WindowTitle; WindowClass=''; WindowHandle=0L
            WindowAction=''; WindowDurationMs=-1; Row=$null
        }
        [void]$script:records.Add($r)
        if ($script:records.Count -gt 2500) {
            $script:records.RemoveAt(0)
            if ($grid.Rows.Count -gt 0) { $grid.Rows.RemoveAt($grid.Rows.Count - 1) }
        }
        [void]$grid.Rows.Insert(0,1)
        $r.Row = $grid.Rows[0]
        $r.Row.Tag = $r
        Update-Row $r
        return
    }
    if ($ev.Source -eq 'TASK129') {
        [void]$script:taskRecords.Add($ev)
        foreach ($r in $script:records) {
            if (($r.ProcId -eq $ev.ProcId) -and ([Math]::Abs(($r.Time - $ev.Time).TotalSeconds) -le 12)) {
                if ($ev.TaskName) { $r.TaskName = $ev.TaskName }
                Update-Row $r
            }
        }
        return
    }
    $isWindow = ([string]$ev.Source -like '창 *')
    if (-not $isWindow -and -not (Is-Candidate $ev.Name)) { return }
    Save-Raw $ev
    $r = $null
    $handle = [long]$ev.WindowHandle
    if ($ev.WindowAction -eq 'HIDE') {
        if ($handle -ne 0) {
            foreach ($old in $script:records) {
                if ($old.WindowHandle -eq $handle -and $old.ProcId -eq $ev.ProcId -and
                    $old.WindowAction -in @('SHOW','CREATE')) { $r = $old; break }
            }
        }
        if ($null -ne $r) {
            $r.WindowAction = 'HIDE'
            $r.WindowDurationMs = [int]$ev.WindowDurationMs
            if (-not $r.WindowTitle -and $ev.WindowTitle) { $r.WindowTitle = [string]$ev.WindowTitle }
            Update-Row $r
            if (($grid.SelectedRows.Count -gt 0) -and ($grid.SelectedRows[0].Tag -eq $r)) { Refresh-Detail }
        }
        return
    }
    foreach ($old in $script:records) {
        if ($old.ProcId -ne $ev.ProcId -or [Math]::Abs(($old.Time - $ev.Time).TotalSeconds) -gt 10) { continue }
        if ($isWindow) {
            # Merge with a process-start row or the same window, never collapse
            # two distinct windows that happen to share a PID.
            if ($old.WindowHandle -eq $handle -and $handle -ne 0) { $r = $old; break }
            if ($old.WindowHandle -eq 0 -and ($old.Name -eq $ev.Name)) { $r = $old; break }
        } else {
            if ($old.Name -eq $ev.Name) { $r = $old; break }
        }
    }
    if ($null -eq $r) {
        $r = [pscustomobject]@{
            Time = [datetime]$ev.Time
            Name = [string]$ev.Name
            ProcId = [int]$ev.ProcId
            ParentId = [int]$ev.ParentId
            Path = [string]$ev.Path
            Command = [string]$ev.Command
            ParentPath = [string]$ev.ParentPath
            ParentCommand = [string]$ev.ParentCommand
            TaskName = [string]$ev.TaskName
            Sources = [string]$ev.Source
            WindowTitle = [string]$ev.WindowTitle
            WindowClass = [string]$ev.WindowClass
            WindowHandle = [long]$ev.WindowHandle
            WindowAction = [string]$ev.WindowAction
            WindowDurationMs = [int]$ev.WindowDurationMs
            Row = $null
        }
        foreach ($task in $script:taskRecords) {
            if (($task.ProcId -eq $r.ProcId) -and ([Math]::Abs(($task.Time - $r.Time).TotalSeconds) -le 12)) {
                $r.TaskName = $task.TaskName
                break
            }
        }
        [void]$script:records.Add($r)
        # Bound GUI memory even during long monitoring sessions. All events
        # still append to JSONL before this screen-level retention limit.
        if ($script:records.Count -gt 2500) {
            $script:records.RemoveAt(0)
            if ($grid.Rows.Count -gt 0) { $grid.Rows.RemoveAt($grid.Rows.Count - 1) }
        }
        # DataGridViewRow does NOT have a DisplayIndex property (only columns do).
        # Insert at row zero so the newest capture stays at the top.
        [void]$grid.Rows.Insert(0, 1)
        $r.Row = $grid.Rows[0]
        $r.Row.Tag = $r
    } else {
        if (-not $r.Path -and $ev.Path) { $r.Path = $ev.Path }
        if (-not $r.Command -and $ev.Command) { $r.Command = $ev.Command }
        if (-not $r.ParentPath -and $ev.ParentPath) { $r.ParentPath = $ev.ParentPath }
        if (-not $r.ParentCommand -and $ev.ParentCommand) { $r.ParentCommand = $ev.ParentCommand }
        if (-not $r.ParentId -and $ev.ParentId) { $r.ParentId = $ev.ParentId }
        if (-not $r.TaskName -and $ev.TaskName) { $r.TaskName = $ev.TaskName }
        if (-not $r.WindowTitle -and $ev.WindowTitle) { $r.WindowTitle = [string]$ev.WindowTitle }
        if (-not $r.WindowClass -and $ev.WindowClass) { $r.WindowClass = [string]$ev.WindowClass }
        if ($r.WindowHandle -eq 0 -and $handle -ne 0) { $r.WindowHandle = $handle }
        if ($ev.WindowAction -eq 'SHOW') { $r.WindowAction = 'SHOW'; $r.WindowDurationMs = -1 }
        if ($ev.WindowAction -eq 'CREATE' -and -not $r.WindowAction) { $r.WindowAction = 'CREATE' }
        if ($r.Sources -notlike "*$($ev.Source)*") { $r.Sources += ' + ' + $ev.Source }
    }
    Update-Row $r
    if (($grid.SelectedRows.Count -gt 0) -and ($grid.SelectedRows[0].Tag -eq $r)) { Refresh-Detail }
}

# WMI process starts. A trace event always has PID, parent PID and image name,
# but command line is a best-effort immediate WMI lookup (fast processes may exit).
$script:wmiAction = {
    try {
        $v = $Event.SourceEventArgs.NewEvent
        $eventPid = [int]$v.ProcessID
        $parentPid = [int]$v.ParentProcessID
        $name = [string]$v.ProcessName
        try { $eventTime = [datetime]::FromFileTimeUtc([long]$v.TIME_CREATED).ToLocalTime() }
        catch { $eventTime = Get-Date }
        $q = $Event.MessageData
        $q.All.Enqueue([pscustomobject]@{ Time=$eventTime; Name=$name; ProcId=$eventPid; ParentId=$parentPid })
        if ($name -notmatch $q.Pattern) { return }
        $path = ''
        $command = ''
        $parentPath = ''
        $parentCommand = ''
        try {
            $child = Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$eventPid" -ErrorAction Stop
            if ($null -ne $child) {
                $path = [string]$child.ExecutablePath
                $command = [string]$child.CommandLine
            }
        } catch { }
        try {
            $parent = Get-CimInstance -ClassName Win32_Process -Filter "ProcessId=$parentPid" -ErrorAction Stop
            if ($null -ne $parent) {
                # Do not silently assign a reused PID to an older child.
                if (([datetime]$parent.CreationDate) -le $eventTime.AddSeconds(3)) {
                    $parentPath = [string]$parent.ExecutablePath
                    $parentCommand = [string]$parent.CommandLine
                }
            }
        } catch { }
        $q.Hits.Enqueue([pscustomobject]@{
            Time=$eventTime; Source='WMI'; Name=$name; ProcId=$eventPid; ParentId=$parentPid
            Path=$path; Command=$command; ParentPath=$parentPath; ParentCommand=$parentCommand; TaskName=''
        })
    } catch { }
}

# Read persisted Windows Event Log creation events, if the corresponding providers
# are enabled already. This tool does NOT silently enable security auditing.
$script:logAction = {
    $rec = $null
    try {
        $rec = $Event.SourceEventArgs.EventRecord
        if ($null -eq $rec) {
            if ($null -ne $Event.SourceEventArgs.EventException) {
                $Event.MessageData.Queue.Enqueue([pscustomobject]@{
                    Time=Get-Date; Source='진단: 이벤트 채널 오류'; Name='이벤트 채널 오류'
                    ProcId=0; ParentId=0; Path=''; Command=[string]$Event.SourceEventArgs.EventException.Message
                    ParentPath=''; ParentCommand=''; TaskName=[string]$Event.MessageData.Mode
                    WindowTitle=''; WindowClass=''; WindowHandle=0L; WindowAction=''; WindowDurationMs=-1
                })
            }
            return
        }
        [xml]$xml = $rec.ToXml()
        $fields = @{}
        foreach ($item in $xml.Event.EventData.Data) {
            $fields[[string]$item.Name] = [string]$item.'#text'
        }
        $mode = [string]$Event.MessageData.Mode
        $q = $Event.MessageData.Queue
        if ($mode -eq 'TASK129') {
            $taskPid = 0
            $pidText = [string]$fields.ProcessID
            if ([int]::TryParse($pidText, [ref]$taskPid) -and $taskPid -gt 0) {
                $q.Enqueue([pscustomobject]@{
                    Time=[datetime]$rec.TimeCreated; Source='TASK129'; ProcId=$taskPid
                    TaskName=[string]$fields.TaskName
                })
            }
            return
        }
        if ($mode -eq 'TASK200' -or $mode -eq 'TASK201') {
            $taskTitle = [string]$fields.TaskName
            $action = [string]$fields.ActionName
            if (-not $action) { $action = [string]$fields.Action }
            $q.Enqueue([pscustomobject]@{
                Time=[datetime]$rec.TimeCreated; Source=('예약 작업 ' + [string]$rec.Id)
                Name= ('예약 작업 ' + [string]$rec.Id)
                ProcId=0; ParentId=0; Path=$action; Command=''
                ParentPath=''; ParentCommand=''; TaskName=$taskTitle
                WindowTitle=$(if ($action) { $action } else { $taskTitle })
                WindowClass=''; WindowHandle=0L; WindowAction=''; WindowDurationMs=-1
            })
            return
        }
        if ($mode -eq 'SERVICE7036' -or $mode -eq 'SERVICE7045' -or $mode -eq 'SERVICE7040') {
            # Service events are contextual evidence; do not invent a process PID.
            $svc = [string]$fields.ServiceName
            if (-not $svc) { $svc = [string]$fields.param1 }
            $stateText = [string]$fields.param2
            $image = [string]$fields.ImagePath
            $q.Enqueue([pscustomobject]@{
                Time=[datetime]$rec.TimeCreated; Source=('서비스 ' + [string]$rec.Id)
                Name= ('서비스 ' + [string]$rec.Id)
                ProcId=0; ParentId=0; Path=$image; Command=''
                ParentPath=''; ParentCommand=''; TaskName=$svc
                WindowTitle=$stateText; WindowClass=''; WindowHandle=0L
                WindowAction=''; WindowDurationMs=-1
            })
            return
        }
        if ($mode -eq 'Security4688') {
            $path = [string]$fields.NewProcessName
            $name = [System.IO.Path]::GetFileName($path)
            if ($name -notmatch $Event.MessageData.Pattern) { return }
            $newId = [string]$fields.NewProcessId
            $creatorId = [string]$fields.ProcessId
            if (-not $newId) { return }
            $pidValue = if ($newId.StartsWith('0x')) { [Convert]::ToInt32($newId.Substring(2),16) } else { [int]$newId }
            $parentValue = if ($creatorId.StartsWith('0x')) { [Convert]::ToInt32($creatorId.Substring(2),16) } else { [int]$creatorId }
            $q.Enqueue([pscustomobject]@{
                Time=[datetime]$rec.TimeCreated; Source='Security 4688'; Name=$name
                ProcId=$pidValue; ParentId=$parentValue; Path=$path
                Command=[string]$fields.CommandLine; ParentPath=[string]$fields.ParentProcessName
                ParentCommand=''; TaskName=''
            })
            return
        }
        if ($mode -eq 'Sysmon1') {
            $path = [string]$fields.Image
            $name = [System.IO.Path]::GetFileName($path)
            if ($name -notmatch $Event.MessageData.Pattern) { return }
            $q.Enqueue([pscustomobject]@{
                Time=[datetime]$rec.TimeCreated; Source='Sysmon 1'; Name=$name
                ProcId=[int]$fields.ProcessId; ParentId=[int]$fields.ParentProcessId; Path=$path
                Command=[string]$fields.CommandLine; ParentPath=[string]$fields.ParentImage
                ParentCommand=[string]$fields.ParentCommandLine; TaskName=''
            })
        }
    } catch { }
    finally { if ($null -ne $rec) { $rec.Dispose() } }
}

function Start-EventLogWatcher([string]$channel, [int]$id, [string]$mode, [string]$source) {
    try {
        $xpath = "*[System[(EventID=$id)]]"
        $query = [System.Diagnostics.Eventing.Reader.EventLogQuery]::new(
            $channel, [System.Diagnostics.Eventing.Reader.PathType]::LogName, $xpath)
        $watcher = [System.Diagnostics.Eventing.Reader.EventLogWatcher]::new($query)
        $reg = Register-ObjectEvent -InputObject $watcher -EventName EventRecordWritten `
            -SourceIdentifier $source -MessageData @{ Queue=$script:hitQueue; Mode=$mode; Pattern=$script:targetRegex } `
            -Action $script:logAction -ErrorAction Stop
        [void]$script:subscriptions.Add($source)
        [void]$script:watchers.Add($watcher)
        $watcher.Enabled = $true
        return $true
    } catch {
        # A subscription could have been created before Enable raised an error.
        try { if ($null -ne $watcher) { $watcher.Enabled = $false; $watcher.Dispose() } } catch { }
        try { Unregister-Event -SourceIdentifier $source -ErrorAction SilentlyContinue } catch { }
        [void]$script:subscriptions.Remove($source)
        if ($null -ne $watcher) { [void]$script:watchers.Remove($watcher) }
        return $false
    }
}

# Always reflect the actual capture state, including when records already exist.
# The first launch starts automatically; clicking Start while running must genuinely restart.
function Update-MonitorButtons {
    $btnStart.Text = if ($script:running) { '감시 재시작' } else { '감시 시작' }
    $btnStop.Enabled = [bool]$script:running
}

function Refresh-MonitorStatus {
    $message = if ($script:running) { [string]$script:monitorInfo + ' / ' + $script:windowState } else { '감시: 중지됨' }
    if ($script:lastAction) { $message += ' | ' + $script:lastAction }
    $message += ' | 기록 ' + [string]$script:records.Count + '건'
    if ($script:records.Count -gt 0) {
        $lastTime = $script:records[$script:records.Count - 1].Time
        $message += ' | 마지막: ' + $lastTime.ToString('HH:mm:ss')
    }
    if ($script:uiErrorCount -gt 0) {
        $message += ' | UI 오류 ' + [string]$script:uiErrorCount + '건 (로그 확인)'
    }
    $status.Text = $message
}

function Stop-Monitor {
    if ($null -ne $script:windowMonitor) {
        try { $script:windowMonitor.Stop(); $script:windowMonitor.Dispose() } catch { }
        $script:windowMonitor = $null
    }
    $script:windowState = '창 감시: 중지됨'
    if ($null -ne $script:nativeMonitor) {
        try { $script:nativeMonitor.Stop(); $script:nativeMonitor.Dispose() } catch { }
        $script:nativeMonitor = $null
    }
    foreach ($w in $script:watchers) {
        try { $w.Enabled = $false; $w.Dispose() } catch { }
    }
    $script:watchers.Clear()
    foreach ($id in $script:subscriptions) {
        try { Unregister-Event -SourceIdentifier $id -ErrorAction SilentlyContinue } catch { }
        try { Get-Job -Name $id -ErrorAction SilentlyContinue | Remove-Job -Force -ErrorAction SilentlyContinue } catch { }
    }
    $script:subscriptions.Clear()
    $script:running = $false
    $script:monitorInfo = '프로세스 감시: 중지됨'
    $script:lastAction = '중지 ' + (Get-Date).ToString('HH:mm:ss') + ' (기록 유지)'
    Update-MonitorButtons
    Refresh-MonitorStatus
}

function Start-Monitor {
    $wasRunning = [bool]$script:running
    if ($wasRunning -or $script:subscriptions.Count -gt 0 -or $null -ne $script:nativeMonitor -or $null -ne $script:windowMonitor) {
        Stop-Monitor
    }
    $script:monitorInfo = ''
    $script:windowState = '창 감시: 대기'
    $key = [guid]::NewGuid().ToString('N').Substring(0,8)
    $wmiId = "CMDDetect_WMI_$key"
    $wmiOk = $false
    $wmiError = ''
    if (-not $script:ForceSnapshot) { try {
        Register-WmiEvent -Class 'Win32_ProcessStartTrace' -Namespace 'root\cimv2' `
            -SourceIdentifier $wmiId `
            -MessageData @{ All=$script:allQueue; Hits=$script:hitQueue; Pattern=$script:targetRegex } `
            -Action $script:wmiAction -ErrorAction Stop | Out-Null
        [void]$script:subscriptions.Add($wmiId)
        $wmiOk = $true
    } catch {
        $wmiError = $_.Exception.Message
    } } else { $wmiError = '사용자가 스냅샷 모드 선택' }

    # WMI requires permission on some Windows systems. Use a read-only,
    # periodic Toolhelp32 snapshot as an automatic fallback.
    $nativeOk = $false
    $nativeError = ''
    if (-not $wmiOk) {
        try {
            $nativeFile = Join-Path $PSScriptRoot 'NativeProcessPoller.cs'
            if (-not ('FlashProcessPoller' -as [type])) {
                Add-Type -Path $nativeFile -ErrorAction Stop
            }
            $script:nativeMonitor = [FlashProcessPoller]::new()
            $script:nativeMonitor.Start($script:allQueue, $script:hitQueue, $script:nativeInterval)
            $nativeOk = $true
        } catch {
            $nativeError = $_.Exception.Message
            try { if ($null -ne $script:nativeMonitor) { $script:nativeMonitor.Dispose() } } catch { }
            $script:nativeMonitor = $null
        }
    }
    if ($wmiOk) {
        $script:monitorInfo = '프로세스 감시: WMI 정상'
    } elseif ($nativeOk) {
        $shortWhy = if ($script:ForceSnapshot) { 'WMI 생략(선택)' } else { 'WMI 실패: ' + $wmiError }
        $script:monitorInfo = "프로세스 감시: 스냅샷 $($script:nativeInterval)ms 정상 / $shortWhy"
    } else {
        $script:monitorInfo = '프로세스 감시 실패: WMI [' + $wmiError + '] / 스냅샷 [' + $nativeError + ']'
    }

    # Windows desktop window-show/hide notifications use a separate message-loop thread.
    # A window can be emitted even if its owning process escaped the 60ms poller.
    $windowOk = $false
    try {
        if (-not ('FlashWindowWatcher' -as [type])) {
            Add-Type -Path (Join-Path $PSScriptRoot 'NativeWindowWatcher.cs') -ErrorAction Stop
        }
        $script:windowMonitor = [FlashWindowWatcher]::new()
        $script:windowMonitor.Start($script:hitQueue)
        $windowOk = $true
        $script:windowState = '창 감시: 이벤트 수신 정상'
    } catch {
        $script:windowState = '창 감시 실패: ' + $_.Exception.Message
        try { if ($null -ne $script:windowMonitor) { $script:windowMonitor.Dispose() } } catch { }
        $script:windowMonitor = $null
    }

    $a = Start-EventLogWatcher 'Security' 4688 'Security4688'  "CMDDetect_SEC_$key"
    $b = Start-EventLogWatcher 'Microsoft-Windows-Sysmon/Operational' 1 'Sysmon1' "CMDDetect_SYSMON_$key"
    $c = Start-EventLogWatcher 'Microsoft-Windows-TaskScheduler/Operational' 129 'TASK129' "CMDDetect_TASK_$key"
    $s1 = if ($a) { '4688 구독' } else { '4688 미사용' }
    $s2 = if ($b) { 'Sysmon 구독' } else { 'Sysmon 미사용' }
    $s3 = if ($c) { '예약 작업 129 구독(수신 별도)' } else { '예약 작업 129 미사용' }
    $extra = @()
    foreach ($c in @(
        @('Microsoft-Windows-TaskScheduler/Operational', 200, 'TASK200','TASK200'),
        @('Microsoft-Windows-TaskScheduler/Operational', 201, 'TASK201','TASK201'),
        @('System',7036,'SERVICE7036','SVC7036'),
        @('System',7045,'SERVICE7045','SVC7045'),
        @('System',7040,'SERVICE7040','SVC7040')
    )) {
        $source = ('CMDDetect_{0}_{1}' -f $c[3],$key)
        if (Start-EventLogWatcher $c[0] ([int]$c[1]) $c[2] $source) { $extra += $c[3] }
    }
    $script:monitorInfo += " / $s1 / $s2 / $s3 / 서비스·작업: $($extra.Count)/5 구독"
    if ($a) {
        $script:auditState = '4688 채널 구독됨(감사 정책 활성 여부는 별도 확인)'
    } else {
        $script:auditState = '4688 구독 실패(권한/정책/채널 확인)'
    }

    if (-not $wmiOk -and -not $nativeOk -and -not $windowOk) {
        $script:running = $false
        [System.Windows.Forms.MessageBox]::Show(
            "프로세스 및 창 감시 시작에 실패했습니다.`r`n$($script:monitorInfo)`r`n$($script:windowState)`r`n`r`nSTART_DEBUG.cmd에서 상세 오류를 확인해 주세요.",
            '감지기 핵심 감시 오류') | Out-Null
    } else {
        $script:running = $true
    }
    if ($script:running) {
        $verb = if ($wasRunning) { '재시작 완료' } else { '감시 시작' }
        $script:lastAction = $verb + ' ' + (Get-Date).ToString('HH:mm:ss')
    } else {
        $script:lastAction = '시작 실패 ' + (Get-Date).ToString('HH:mm:ss')
    }
    Update-MonitorButtons
    Refresh-MonitorStatus
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 300
$timer.Add_Tick({
    try {
    if ($null -ne $script:windowMonitor) {
        if ($script:windowMonitor.LastError) { $script:windowState = '창 감시 점검: ' + $script:windowMonitor.LastError }
        elseif (-not $script:windowMonitor.IsRunning) { $script:windowState = '창 감시 중단(스레드 종료)' }
    }
    if ($null -ne $script:nativeMonitor -and $script:nativeMonitor.LastError) {
        $script:monitorInfo = '스냅샷 오류: ' + $script:nativeMonitor.LastError
    }
    $item = $null
    $count = 0
    while (($count -lt 600) -and $script:allQueue.TryDequeue([ref]$item)) {
        [void]$script:recent.Add($item)
        $count++
    }
    # Keep 1,000 recent process starts, covering nearby processes without long-term sampling.
    while ($script:recent.Count -gt 1000) { $script:recent.RemoveAt(0) }
    $count = 0
    while (($count -lt 300) -and $script:hitQueue.TryDequeue([ref]$item)) {
        Apply-Event $item
        $count++
    }
    Refresh-MonitorStatus
    } catch {
        Write-UiError 'Timer.OnTick' $_
    }
})

$btnStart.Add_Click({
    try { Start-Monitor }
    catch { Write-UiError 'StartButton' $_ }
})
$btnStop.Add_Click({
    try { Stop-Monitor }
    catch { Write-UiError 'StopButton' $_ }
})
$btnTest.Add_Click({
    if (-not $script:running) {
        [System.Windows.Forms.MessageBox]::Show('먼저 감시를 시작하세요.', '안내') | Out-Null
        return
    }
    try {
        Start-Process -FilePath $env:ComSpec -ArgumentList '/d /c powershell.exe -NoProfile -NonInteractive -Command "Start-Sleep -Seconds 2"' -WindowStyle Normal -ErrorAction Stop | Out-Null
    } catch {
        [System.Windows.Forms.MessageBox]::Show('테스트 실행 실패: ' + $_.Exception.Message, '안내') | Out-Null
    }
})
$btnExport.Add_Click({
    if (Export-Data) { [System.Windows.Forms.MessageBox]::Show("CSV 저장 완료:`r`n$script:csvFile", '내보내기') | Out-Null }
})
$btnFolder.Add_Click({ [System.Diagnostics.Process]::Start('explorer.exe', '"' + $script:logDir + '"') | Out-Null })
$btnCopy.Add_Click({
    if ($detail.Text) { [System.Windows.Forms.Clipboard]::SetText($detail.Text) }
})
$btnCopyStatus.Add_Click({
    $body = "CMD 감지기 2.0 - 상태`r`n" + $script:monitorInfo + ' / ' + $script:windowState
    $body += "`r`n감사 로그 상태: $script:auditState"
    $body += "`r`n감시 활성: " + [string]$script:running
    $body += "`r`n마지막 조작: " + [string]$script:lastAction
    $body += "`r`nUI 오류: " + [string]$script:uiErrorCount
    $body += "`r`nUI 오류 로그: " + $script:uiErrorFile
    if ($null -ne $script:windowMonitor) {
        $body += "`r`n창 표시 횟수: " + [string]$script:windowMonitor.ShowCount
        $body += "`r`n창 숨김 횟수: " + [string]$script:windowMonitor.HideCount
        $body += "`r`n창 감시 오류: " + [string]$script:windowMonitor.LastError
    }
    if ($null -ne $script:nativeMonitor) {
        $body += "`r`n스냅샷 수행 횟수: " + [string]$script:nativeMonitor.PollCount
        $body += "`r`n스냅샷 오류: " + [string]$script:nativeMonitor.LastError
    }
    try { [System.Windows.Forms.Clipboard]::SetText($body) } catch { }
})
$btnTestWindow.Add_Click({
    if (-not $script:running) {
        [System.Windows.Forms.MessageBox]::Show('먼저 감시를 시작하세요.', '안내') | Out-Null
        return
    }
    try {
        $scriptFile = Join-Path $PSScriptRoot 'TEST_WINDOW_POPUP.ps1'
        Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList @(
            '-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $scriptFile + '"')
        ) -ErrorAction Stop | Out-Null
    } catch {
        [System.Windows.Forms.MessageBox]::Show('짧은 창 테스트 실패: ' + $_.Exception.Message, '안내') | Out-Null
    }
})
$btnPrecise.Add_Click({
    $answer = [System.Windows.Forms.MessageBox]::Show(
        "정밀 모드에서는 Windows 보안 감사 4688을 사용합니다.`r`n기본 감시에는 관리자 권한이 필요하지 않습니다.`r`n`r`n별도 ENABLE_PRECISE_AUDIT_ADMIN.cmd를 직접 실행하면 보안 감사 설정이 변경됩니다.`r`n명령줄 기록에는 개인 정보가 포함될 수 있습니다.`r`n`r`n감사 설정 안내 폴더를 열까요?",
        '정밀 감사 설정 안내','YesNo','Information')
    if ($answer -eq 'Yes') { [System.Diagnostics.Process]::Start('explorer.exe', ('"' + $PSScriptRoot + '"')) | Out-Null }
})
$btnProbe.Add_Click({
    $a = "감지기 v2.0 진단" + "`r`n" + $script:monitorInfo + "`r`n" + $script:windowState
    $a += "`r`n" + $script:auditState + "`r`n감시 작동: " + $script:running
    $a += "`r`n이벤트: " + $script:records.Count + "`r`n서비스·예약 작업: " + $script:contextRecords.Count
    try { [System.Windows.Forms.Clipboard]::SetText($a) } catch { }
    [System.Windows.Forms.MessageBox]::Show($a + "`r`n`r`n진단이 클립보드에 복사되었습니다.",'감시 상태 진단') | Out-Null
})
$btnGuide.Add_Click({
    $guideText = @'
WMI 등록이 권한 문제로 실패하면 스냅샷 감시(60ms)로 자동 전환합니다.
창 표시/숨김 이벤트 감시는 별도의 Windows API를 사용합니다.
스냅샷 방식은 두 검사 사이에 시작해서 끝난 프로세스를 놓칠 수 있습니다.
검출 시각은 실제 시작 시각이 아니라 첫 스냅샷 관측 시각입니다.

더 정확하게 기록하려면 관리자 권한으로 실행하거나
Windows 보안 감사 4688의 프로세스 생성 및 명령줄 기록을 설정할 수 있습니다.
설정에는 관리자 권한이 필요하며, 이 앱은 보안 정책을 임의로 변경하지 않습니다.

동봉된 README_KO.txt의 '정밀 기록 설정' 절을 참고하세요.
시작 후 'CMD 실행 테스트'와 '짧은 창 테스트'를 각각 누르세요.
창 감지는 같은 로그인 데스크톱의 창만 대상으로 하며 완전한 보장을 제공하지 않습니다.

주의: 감사 정책을 활성화하면 모든 프로세스 명령줄이 Windows 보안 로그에 기록될 수 있으며 민감한 정보가 포함될 수 있습니다.
'@
    [System.Windows.Forms.MessageBox]::Show($guideText, '정밀 기록 안내') | Out-Null
})
$form.Add_FormClosing({
    $timer.Stop()
    Stop-Monitor
    if ($script:records.Count -gt 0) { [void](Export-Data) }
})

try {
    Update-MonitorButtons
    Start-Monitor
    $timer.Start()
    [void]$form.ShowDialog()
} catch {
    try {
        [System.IO.File]::AppendAllText((Join-Path $script:root 'startup_error.txt'), ($_ | Out-String))
        [System.Windows.Forms.MessageBox]::Show('프로그램 오류: ' + $_.Exception.Message + "`r`n$script:root", 'CMD 감지기') | Out-Null
    } catch { }
} finally {
    try { $timer.Stop(); Stop-Monitor } catch { }
    try { $form.Dispose() } catch { }
}

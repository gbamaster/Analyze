# Self-test popup for the SetWinEventHook listener. No files or system changes.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$form = New-Object System.Windows.Forms.Form
$form.Text = 'CMD_DETECTOR_WINDOW_TEST_1500ms'
$form.Width = 480
$form.Height = 160
$form.StartPosition = 'CenterScreen'
$label = New-Object System.Windows.Forms.Label
$label.AutoSize = $true
$label.Text = 'Short-lived window test (not a CMD console)'
$label.Location = New-Object System.Drawing.Point(20, 30)
$form.Controls.Add($label)
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1500
$timer.Add_Tick({ $timer.Stop(); $form.Close() })
$form.Add_Shown({ $timer.Start() })
[void]$form.ShowDialog()
$timer.Dispose()
$form.Dispose()

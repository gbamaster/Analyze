﻿# v2.0 Windows PowerShell 5.1 self-tests. No elevation, persistence, or security policy change.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$failed = 0
function Pass([string]$name) { Write-Host "[PASS] $name" -ForegroundColor Green }
function Fail([string]$name, $errorInfo) {
    $script:failed++
    Write-Host "[FAIL] $name : $errorInfo" -ForegroundColor Red
}

try {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
        (Join-Path $PSScriptRoot 'CMD_Window_Detector.ps1'), [ref]$tokens, [ref]$errors)
    if ($errors.Count -gt 0) { throw ($errors | Out-String) }
    Pass 'PowerShell script parsing'
} catch { Fail 'PowerShell script parsing' $_ }

foreach ($file in @('ENABLE_PRECISE_AUDIT_ADMIN.ps1','RESTORE_PRECISE_AUDIT_ADMIN.ps1','QUICK_DIAG.ps1')) {
    try {
        $tokens = $null
        $errors = $null
        [void][System.Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot $file), [ref]$tokens, [ref]$errors)
        if ($errors.Count) { throw ($errors | Out-String) }
        Pass ("Syntax: " + $file)
    } catch { Fail ("Syntax: " + $file) $_ }
}

try {
    Add-Type -Path (Join-Path $PSScriptRoot 'NativeProcessPoller.cs') -ErrorAction Stop
    Pass 'Native process monitor C# compilation'
} catch { Fail 'Native process monitor C# compilation' $_ }

try {
    Add-Type -Path (Join-Path $PSScriptRoot 'NativeWindowWatcher.cs') -ErrorAction Stop
    Pass 'Native window-event monitor C# compilation'
} catch { Fail 'Native window-event monitor C# compilation' $_ }

try {
    $grid = New-Object System.Windows.Forms.DataGridView
    $grid.AllowUserToAddRows = $false
    foreach ($field in @('time','name','window','pid','parent','task','source')) {
        [void]$grid.Columns.Add($field, $field)
    }
    [void]$grid.Rows.Insert(0,1)
    $grid.Rows[0].Tag = [pscustomobject]@{Name='cmd.exe'}
    [void]$grid.Rows.Insert(0,1)
    $grid.Rows[0].Tag = [pscustomobject]@{Name='notepad.exe'}
    if ($grid.Rows.Count -ne 2 -or $grid.Rows[0].Tag.Name -ne 'notepad.exe') {
        throw 'Order or row handling incorrect.'
    }
    $grid.Dispose()
    Pass 'GUI row schema and newest-first insertion'
} catch { Fail 'GUI row schema and newest-first insertion' $_ }

if ('FlashProcessPoller' -as [type]) {
    $watcher = $null
    try {
        $all = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
        $hits = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
        $watcher = [FlashProcessPoller]::new()
        $watcher.Start($all, $hits, 60)
        Start-Process -FilePath $env:ComSpec -ArgumentList '/d /c powershell.exe -NoProfile -NonInteractive -Command "Start-Sleep -Seconds 2"' -WindowStyle Hidden -ErrorAction Stop | Out-Null
        Start-Sleep -Milliseconds 1300
        $ev = $null
        $found = $false
        while ($hits.TryDequeue([ref]$ev)) {
            if ($ev.Name -eq 'cmd.exe') { $found = $true }
        }
        if (-not $found) { throw ('CMD not detected. Polls=' + $watcher.PollCount + '; ' + $watcher.LastError) }
        Pass '60ms snapshot detects two-second cmd process'
    } catch { Fail '60ms snapshot detects two-second cmd process' $_ }
    finally { if ($null -ne $watcher) { $watcher.Dispose() } }
}

if ('FlashWindowWatcher' -as [type]) {
    $watcher = $null
    try {
        $queue = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
        $watcher = [FlashWindowWatcher]::new()
        $watcher.Start($queue)
        if (-not $watcher.IsRunning) { throw ('Window hook is not running: ' + $watcher.LastError) }
        $testFile = Join-Path $PSScriptRoot 'TEST_WINDOW_POPUP.ps1'
        $quotedFile = '"' + $testFile + '"'
        Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') `
            -ArgumentList @('-NoProfile','-STA','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File', $quotedFile) -ErrorAction Stop | Out-Null
        Start-Sleep -Milliseconds 3500
        $item = $null
        $seen = $false
        $closed = $false
        while ($queue.TryDequeue([ref]$item)) {
            if ($item.WindowTitle -eq 'CMD_DETECTOR_WINDOW_TEST_1500ms') {
                if ($item.WindowAction -eq 'SHOW') { $seen = $true }
                if ($item.WindowAction -eq 'HIDE' -and $item.WindowDurationMs -ge 0) { $closed = $true }
            }
        }
        if (-not $seen) { throw ('Popup show was not received: ' + $watcher.LastError) }
        Pass 'Non-console popup window show event'
        if (-not $closed) { throw ('Popup hide was not received: ' + $watcher.LastError) }
        Pass 'Popup hide event and duration'
    } catch { Fail 'Window popup event integration test' $_ }
    finally { if ($null -ne $watcher) { $watcher.Dispose() } }
}

Write-Host ''
if ($failed -gt 0) { Write-Host "FAILED: $failed test(s)" -ForegroundColor Red; exit 1 }
Write-Host 'ALL TESTS PASSED (Windows only; Security 4688 end-to-end needs opt-in auditing)'  -ForegroundColor Green
exit 0

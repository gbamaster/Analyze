@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0CMD_Window_Detector.ps1"
echo.
echo If the UI did not open, copy the error above and send it for diagnosis.
pause

@echo off
cmd /d /c "echo CMD Flash Detector Test & timeout /t 1 /nobreak >nul"

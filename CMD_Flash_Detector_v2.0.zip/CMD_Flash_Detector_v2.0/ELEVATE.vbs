Option Explicit
Dim fso, sh, action, folder, scriptName, args
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("Shell.Application")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
action = ""
If WScript.Arguments.Count > 0 Then action = LCase(WScript.Arguments(0))
Select Case action
  Case "enable"
    scriptName = "ENABLE_PRECISE_AUDIT_ADMIN.ps1"
    args = "-NoProfile -ExecutionPolicy Bypass -NoExit -File """ & folder & "\" & scriptName & """"
  Case "restore"
    scriptName = "RESTORE_PRECISE_AUDIT_ADMIN.ps1"
    args = "-NoProfile -ExecutionPolicy Bypass -NoExit -File """ & folder & "\" & scriptName & """"
  Case "start"
    scriptName = "CMD_Window_Detector.ps1"
    args = "-NoProfile -STA -ExecutionPolicy Bypass -File """ & folder & "\" & scriptName & """"
  Case Else
    MsgBox "Unknown action", vbExclamation
    WScript.Quit 1
End Select
sh.ShellExecute "powershell.exe", args, folder, "runas", 1

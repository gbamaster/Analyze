@echo off
setlocal
REM Runs only the read-only native snapshot monitor; no policy changes.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0CMD_Window_Detector.ps1" -ForceSnapshot
if errorlevel 1 pause

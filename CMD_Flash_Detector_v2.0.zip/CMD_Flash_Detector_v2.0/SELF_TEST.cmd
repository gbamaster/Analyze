@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0SelfTest.ps1"
set "rc=%ERRORLEVEL%"
echo.
echo TEST EXIT CODE: %rc%
pause
exit /b %rc%

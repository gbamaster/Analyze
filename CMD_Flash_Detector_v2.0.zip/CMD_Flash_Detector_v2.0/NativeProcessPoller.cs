// NativeProcessPoller.cs - Windows 10/11, .NET Framework 4.x / PowerShell 5.1.
// Read-only, local process snapshot monitor. No installation or privileged changes.
// Toolhelp32 misses processes that start and exit between snapshots.
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

public sealed class FlashProcessEvent
{
    public DateTime Time { get; set; }
    public string Source { get; set; }
    public string Name { get; set; }
    public int ProcId { get; set; }
    public int ParentId { get; set; }
    public string Path { get; set; }
    public string Command { get; set; }
    public string ParentPath { get; set; }
    public string ParentCommand { get; set; }
    public string TaskName { get; set; }
}

public sealed class FlashProcessPoller : IDisposable
{
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    private struct PROCESSENTRY32
    {
        public uint dwSize;
        public uint cntUsage;
        public uint th32ProcessID;
        public IntPtr th32DefaultHeapID;
        public uint th32ModuleID;
        public uint cntThreads;
        public uint th32ParentProcessID;
        public int pcPriClassBase;
        public uint dwFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=260)]
        public string szExeFile;
    }

    [DllImport("kernel32.dll", SetLastError=true)]
    private static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint processId);
    [DllImport("kernel32.dll", EntryPoint="Process32FirstW", CharSet=CharSet.Unicode, SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool Process32First(IntPtr h, ref PROCESSENTRY32 entry);
    [DllImport("kernel32.dll", EntryPoint="Process32NextW", CharSet=CharSet.Unicode, SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool Process32Next(IntPtr h, ref PROCESSENTRY32 entry);
    [DllImport("kernel32.dll", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32.dll", SetLastError=true)]
    private static extern IntPtr OpenProcess(uint desiredAccess, bool inheritHandle, uint processId);
    [DllImport("kernel32.dll", EntryPoint="QueryFullProcessImageNameW", CharSet=CharSet.Unicode, SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool QueryFullProcessImageName(IntPtr process, int flags, StringBuilder text, ref int size);

    private sealed class Proc
    {
        public int Pid;
        public int ParentPid;
        public string Name;
    }

    private static readonly Regex Target = new Regex(
        @"^(cmd|powershell|pwsh|conhost|openconsole|wt|windowsterminal|wscript|cscript|mshta|taskeng|schtasks|python|pythonw|bash|wsl)\.exe$",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled);
    private ConcurrentQueue<object> _all;
    private ConcurrentQueue<object> _hits;
    private Dictionary<int, Proc> _previous = new Dictionary<int, Proc>();
    private Timer _timer;
    private volatile bool _stopped = true;
    private int _active;
    private int _interval;
    public string LastError { get; private set; }
    public int PollCount { get; private set; }

    private static Dictionary<int, Proc> Snapshot()
    {
        IntPtr handle = CreateToolhelp32Snapshot(2, 0);
        if (handle == new IntPtr(-1))
            throw new Win32Exception(Marshal.GetLastWin32Error(), "CreateToolhelp32Snapshot");
        var results = new Dictionary<int, Proc>();
        try
        {
            PROCESSENTRY32 entry = new PROCESSENTRY32();
            entry.dwSize = (uint)Marshal.SizeOf(typeof(PROCESSENTRY32));
            if (!Process32First(handle, ref entry))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "Process32First");
            do
            {
                if (entry.th32ProcessID > 0 && entry.th32ProcessID <= int.MaxValue)
                {
                    int pid = (int)entry.th32ProcessID;
                    results[pid] = new Proc {
                        Pid = pid,
                        ParentPid = entry.th32ParentProcessID <= int.MaxValue ? (int)entry.th32ParentProcessID : 0,
                        Name = entry.szExeFile ?? ""
                    };
                }
            } while (Process32Next(handle, ref entry));
        }
        finally { CloseHandle(handle); }
        return results;
    }

    private static string ExecutablePath(int pid)
    {
        if (pid <= 0) return "";
        IntPtr process = OpenProcess(0x1000, false, (uint)pid); // PROCESS_QUERY_LIMITED_INFORMATION
        if (process == IntPtr.Zero) return "";
        try
        {
            var buffer = new StringBuilder(32768);
            int size = buffer.Capacity;
            return QueryFullProcessImageName(process, 0, buffer, ref size) ? buffer.ToString() : "";
        }
        finally { CloseHandle(process); }
    }

    public void Start(ConcurrentQueue<object> all, ConcurrentQueue<object> hits, int intervalMs)
    {
        if (all == null || hits == null) throw new ArgumentNullException("queues");
        if (!_stopped) throw new InvalidOperationException("Monitor already started.");
        if (intervalMs < 30 || intervalMs > 5000) throw new ArgumentOutOfRangeException("intervalMs");
        _all = all;
        _hits = hits;
        _interval = intervalMs;
        LastError = "";
        _previous = Snapshot(); // Baseline: only newly created processes are reported.
        _stopped = false;
        _timer = new Timer(Poll, null, _interval, _interval);
    }

    private void Poll(object unused)
    {
        if (_stopped || Interlocked.Exchange(ref _active, 1) != 0) return;
        try
        {
            var current = Snapshot();
            if (_stopped) return;
            DateTime time = DateTime.Now;
            foreach (var p in current.Values)
            {
                if (_previous.ContainsKey(p.Pid)) continue;
                // Keep neighbor process starts for context.
                var allRecord = new FlashProcessEvent {
                    Time = time, Source = "SNAPSHOT", Name = p.Name, ProcId = p.Pid, ParentId = p.ParentPid
                };
                _all.Enqueue(allRecord);
                if (!Target.IsMatch(p.Name)) continue;
                string childPath = ExecutablePath(p.Pid);
                string parentPath = ExecutablePath(p.ParentPid);
                if (parentPath.Length == 0)
                {
                    Proc parent;
                    if (current.TryGetValue(p.ParentPid, out parent) || _previous.TryGetValue(p.ParentPid, out parent))
                        parentPath = "[이름만 확인] " + parent.Name;
                }
                _hits.Enqueue(new FlashProcessEvent {
                    Time = time, Source = "스냅샷 " + _interval + "ms", Name = p.Name,
                    ProcId = p.Pid, ParentId = p.ParentPid, Path = childPath,
                    Command = "", ParentPath = parentPath, ParentCommand = "", TaskName = ""
                });
            }
            _previous = current;
            PollCount++;
        }
        catch (Exception ex) { LastError = ex.GetType().Name + ": " + ex.Message; }
        finally { Interlocked.Exchange(ref _active, 0); }
    }

    public void Stop()
    {
        _stopped = true;
        var t = Interlocked.Exchange(ref _timer, null);
        if (t != null) t.Dispose();
    }

    public void Dispose() { Stop(); }
}

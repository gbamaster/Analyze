# No policy mutation. Prints whether audit events are actually present.
$now = Get-Date
Write-Host "Time: $now"
Write-Host "OS: $([Environment]::OSVersion.VersionString)"
Write-Host 'Process auditing policy:'
& auditpol.exe /get '/subcategory:{0CCE922B-69AE-11D9-BED3-505054503030}'
Write-Host 'Command line audit value:'
try { Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit' -Name 'ProcessCreationIncludeCmdLine_Enabled' -ErrorAction Stop | Select-Object -ExpandProperty ProcessCreationIncludeCmdLine_Enabled } catch { Write-Host 'Not set' }
foreach ($q in @(
    @('Security',4688),
    @('Microsoft-Windows-Sysmon/Operational',1),
    @('Microsoft-Windows-TaskScheduler/Operational',200),
    @('System',7036))) {
    try {
        $event = Get-WinEvent -FilterHashtable @{LogName=$q[0]; Id=[int]$q[1]; StartTime=$now.AddMinutes(-30)} -MaxEvents 1 -ErrorAction Stop
        Write-Host "OK $($q[0]) ID=$($q[1]) most recent: $($event.TimeCreated)"
    } catch {
        Write-Host "NOT AVAILABLE/NO MATCH $($q[0]) ID=$($q[1]): $($_.Exception.Message)"
    }
}

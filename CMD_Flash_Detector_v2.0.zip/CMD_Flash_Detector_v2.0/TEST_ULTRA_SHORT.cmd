@echo off
rem Five very short console processes. Requires enabled Security 4688 for reliable capture.
for /L %%I in (1,1,5) do start "" /min "%ComSpec%" /d /c exit /b 0
pause

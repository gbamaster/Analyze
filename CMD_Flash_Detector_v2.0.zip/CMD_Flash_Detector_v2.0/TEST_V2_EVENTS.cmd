@echo off
cd /d "%~dp0"
echo [1] Opening a visible CMD for 2 seconds
start "" "%ComSpec%" /d /c "timeout /t 2 /nobreak >nul"
echo [2] Creating five short-lived console processes
for /L %%I in (1,1,5) do start "" /min "%ComSpec%" /d /c exit /b 0
echo [3] Inspect 4688 if auditing was explicitly enabled, otherwise short starts can be missed.
pause

# Standalone copy/paste fallback for Windows PowerShell 5.1.
# Captures window show/hide + starts with polling; reads 4688/service/task if logged.
# No security setting modifications. Ctrl+C stops.
$ErrorActionPreference = 'Continue'
$root = Join-Path $env:LOCALAPPDATA 'CMD_Flash_Detector\Logs'
New-Item -ItemType Directory -Path $root -Force | Out-Null
$file = Join-Path $root ('copy_mode_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt')
$native = @'
using System;
using System.Collections.Concurrent;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
public sealed class InlineWindowWatch {
  public ConcurrentQueue<string> Events = new ConcurrentQueue<string>();
  const uint SHOW=0x8002, HIDE=0x8003, FORE=3, SKIP=2, QUIT=0x12;
  private delegate void CB(IntPtr h,uint ev,IntPtr win,int obj,int child,uint tid,uint ms);
  private CB callback;
  private Thread thread;
  private uint threadId;
  private IntPtr one,two;
  private ManualResetEventSlim ready = new ManualResetEventSlim(false);
  [StructLayout(LayoutKind.Sequential)] struct MSG {
    public IntPtr hwnd; public uint message; public IntPtr wp,lp;
    public uint time; public int x,y,lprivate;
  }
  [DllImport("user32.dll")] static extern IntPtr SetWinEventHook(uint a,uint b,IntPtr lib,CB cb,uint pid,uint tid,uint flags);
  [DllImport("user32.dll")] static extern bool UnhookWinEvent(IntPtr h);
  [DllImport("user32.dll")] static extern int GetMessage(out MSG m,IntPtr h,uint a,uint b);
  [DllImport("user32.dll")] static extern bool PeekMessage(out MSG m,IntPtr h,uint a,uint b,uint rm);
  [DllImport("user32.dll")] static extern bool PostThreadMessage(uint id,uint msg,IntPtr w,IntPtr l);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h,out uint id);
  [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr h,uint mode);
  [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
  [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h,StringBuilder s,int n);
  void Event(IntPtr h,uint ev,IntPtr win,int obj,int child,uint tid,uint ms) {
    if(win==IntPtr.Zero||obj!=0||child!=0||GetAncestor(win,2)!=win)return;
    uint pid;GetWindowThreadProcessId(win,out pid);
    if(pid==0||pid==(uint)System.Diagnostics.Process.GetCurrentProcess().Id)return;
    var title=new StringBuilder(512);var cls=new StringBuilder(256);
    GetWindowText(win,title,title.Capacity);GetClassName(win,cls,cls.Capacity);
    Events.Enqueue(DateTime.Now.ToString("HH:mm:ss.fff")+" WIN "+(ev==HIDE?"HIDE":"SHOW")+" PID="+pid+" ["+cls+"] "+title);
  }
  public void Start(){
    thread=new Thread(()=>{threadId=GetCurrentThreadId(); MSG m;PeekMessage(out m,IntPtr.Zero,0,0,0);
      callback=Event;
      one=SetWinEventHook(SHOW,HIDE,IntPtr.Zero,callback,0,0,SKIP);
      two=SetWinEventHook(FORE,FORE,IntPtr.Zero,callback,0,0,SKIP);
      ready.Set();
      while(GetMessage(out m,IntPtr.Zero,0,0)>0){}
      if(one!=IntPtr.Zero)UnhookWinEvent(one);if(two!=IntPtr.Zero)UnhookWinEvent(two);
    });thread.IsBackground=true;thread.Start();
    if(!ready.Wait(4000)||one==IntPtr.Zero||two==IntPtr.Zero)throw new Exception("WinEvent hook start failed");
  }
  public void Stop(){if(threadId!=0)PostThreadMessage(threadId,QUIT,IntPtr.Zero,IntPtr.Zero);}
}
'@
try {
  if (-not ('InlineWindowWatch' -as [type])) { Add-Type -TypeDefinition $native -ErrorAction Stop }
  $watch = [InlineWindowWatch]::new()
  $watch.Start()
} catch { Write-Host ('Window capture failed: ' + $_.Exception.Message) -ForegroundColor Yellow; $watch = $null }
$lastLogCheck = (Get-Date).AddSeconds(-2)
$already = New-Object 'System.Collections.Generic.HashSet[string]'
$previous = @{}
function OutputLine([string]$line) {
  Write-Host $line
  [System.IO.File]::AppendAllText($file, ($line + [Environment]::NewLine))
}
OutputLine "Monitoring started $(Get-Date -Format o); press Ctrl+C to stop; $file"
try {
  while ($true) {
    if ($null -ne $watch) {
      $win = ''
      while ($watch.Events.TryDequeue([ref]$win)) { OutputLine $win }
    }
    $next = @{}
    foreach ($p in @(Get-Process -ErrorAction SilentlyContinue)) {
      $id = [int]$p.Id
      $next[$id] = $p.ProcessName
      if ($previous.Count -gt 0 -and -not $previous.ContainsKey($id) -and $p.ProcessName -match '^(cmd|conhost|powershell|pwsh|wscript|cscript|mshta|OpenConsole|WindowsTerminal|sdbinst)$') {
        OutputLine ((Get-Date -Format 'HH:mm:ss.fff') + ' SNAPSHOT PID=' + $id + ' ' + $p.ProcessName)
      }
    }
    $previous = $next
    if (((Get-Date) - $lastLogCheck).TotalSeconds -ge 2) {
      $before = $lastLogCheck.AddMilliseconds(-300)
      $lastLogCheck = Get-Date
      foreach ($item in @(@('Security',4688),@('Microsoft-Windows-TaskScheduler/Operational',200),@('System',7036),@('System',7045))) {
        try {
          $events = @(Get-WinEvent -FilterHashtable @{LogName=$item[0]; Id=[int]$item[1]; StartTime=$before} -MaxEvents 250 -ErrorAction Stop)
          foreach ($e in $events) {
            $key = $item[0] + ':' + $e.RecordId
            if (-not $already.Add($key)) { continue }
            if ($item[1] -eq 4688) {
              [xml]$xml = $e.ToXml(); $fields=@{}
              foreach ($d in $xml.Event.EventData.Data) { $fields[[string]$d.Name] = [string]$d.'#text' }
              $name = [string]$fields.NewProcessName
              if ($name -notmatch '\\(cmd|conhost|powershell|pwsh|wscript|cscript|mshta|sdbinst|AsusSoftwareManager)\.exe$') { continue }
              OutputLine ($e.TimeCreated.ToString('HH:mm:ss.fff') + ' SECURITY4688 ' + $name + ' PID=' + $fields.NewProcessId + ' parent=' + $fields.ParentProcessName + ' cmd=' + $fields.CommandLine)
            } else {
              $msg = ([string]$e.Message -replace '[\r\n]+',' ')
              OutputLine ($e.TimeCreated.ToString('HH:mm:ss.fff') + ' ' + $item[0] + ':' + $item[1] + ' ' + $msg.Substring(0,[Math]::Min(300,$msg.Length)))
            }
          }
        } catch { }
      }
      if ($already.Count -gt 15000) { $already.Clear() }
    }
    Start-Sleep -Milliseconds 80
  }
} finally {
  if ($null -ne $watch) { $watch.Stop() }
}

// NativeWindowWatcher.cs - visible window notifications for Windows PowerShell 5.1.
// Read-only SetWinEventHook (out-of-context), in this user's interactive desktop.
// Not a process creation audit; cannot guarantee detection of every brief window.
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public sealed class FlashWindowEvent
{
    public DateTime Time { get; set; }
    public string Source { get; set; }
    public string Name { get; set; }
    public int ProcId { get; set; }
    public int ParentId { get; set; }
    public string Path { get; set; }
    public string Command { get; set; }
    public string ParentPath { get; set; }
    public string ParentCommand { get; set; }
    public string TaskName { get; set; }
    public string WindowTitle { get; set; }
    public string WindowClass { get; set; }
    public long WindowHandle { get; set; }
    public string WindowAction { get; set; }
    public int WindowDurationMs { get; set; }
}

public sealed class FlashWindowWatcher : IDisposable
{
    private const uint EVENT_SYSTEM_FOREGROUND = 0x0003;
    private const uint EVENT_OBJECT_CREATE = 0x8000;
    private const uint EVENT_OBJECT_DESTROY = 0x8001;
    private const uint EVENT_OBJECT_SHOW = 0x8002;
    private const uint EVENT_OBJECT_HIDE = 0x8003;
    private const uint WINEVENT_OUTOFCONTEXT = 0;
    private const uint WINEVENT_SKIPOWNPROCESS = 2;
    private const int OBJID_WINDOW = 0;
    private const uint GA_ROOT = 2;
    private const uint WM_QUIT = 0x0012;
    private const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;

    private delegate void WinEventProc(IntPtr hook, uint eventType, IntPtr hwnd,
        int idObject, int idChild, uint eventThread, uint eventTime);
    [StructLayout(LayoutKind.Sequential)]
    private struct POINT { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)]
    private struct MSG
    {
        public IntPtr hwnd;
        public uint message;
        public IntPtr wParam;
        public IntPtr lParam;
        public uint time;
        public POINT pt;
        public int lPrivate;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct PROCESS_BASIC_INFORMATION
    {
        public IntPtr Reserved1;
        public IntPtr PebBaseAddress;
        public IntPtr Reserved2_0;
        public IntPtr Reserved2_1;
        public IntPtr UniqueProcessId;
        public IntPtr InheritedFromUniqueProcessId;
    }
    private sealed class VisibleWindow
    {
        public FlashWindowEvent Record;
        public DateTime Time;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWinEventHook(uint eventMin, uint eventMax,
        IntPtr module, WinEventProc callback, uint process, uint thread, uint flags);
    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWinEvent(IntPtr hook);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern int GetMessage(out MSG message, IntPtr hwnd, uint min, uint max);
    [DllImport("user32.dll")]
    private static extern bool TranslateMessage(ref MSG message);
    [DllImport("user32.dll")]
    private static extern IntPtr DispatchMessage(ref MSG message);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool PeekMessage(out MSG message, IntPtr hwnd, uint min, uint max, uint remove);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool PostThreadMessage(uint threadId, uint message, IntPtr wparam, IntPtr lparam);
    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll")]
    private static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassName(IntPtr hwnd, StringBuilder buffer, int capacity);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hwnd, StringBuilder buffer, int capacity);
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr OpenProcess(uint access, bool inheritHandle, uint pid);
    [DllImport("kernel32.dll", EntryPoint = "QueryFullProcessImageNameW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool QueryFullProcessImageName(IntPtr process, int flags, StringBuilder buffer, ref int size);
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CloseHandle(IntPtr handle);
    [DllImport("ntdll.dll")]
    private static extern int NtQueryInformationProcess(IntPtr handle, int processInformationClass,
        ref PROCESS_BASIC_INFORMATION processInformation, int processInformationLength, out int returnLength);

    private ConcurrentQueue<object> _hits;
    private Thread _thread;
    private uint _threadId;
    private WinEventProc _callback; // strong reference for managed callback
    private GCHandle _callbackRoot;
    private IntPtr _showHook;
    private IntPtr _createHook;
    private IntPtr _foregroundHook;
    private ManualResetEventSlim _ready = new ManualResetEventSlim(false);
    private Dictionary<long, VisibleWindow> _windows = new Dictionary<long, VisibleWindow>();
    private volatile bool _stop;
    private string _error = "";
    private int _showCount;
    private int _hideCount;
    private int _selfPid;
    public string LastError { get { return _error; } }
    public int ShowCount { get { return _showCount; } }
    public int HideCount { get { return _hideCount; } }
    public bool IsRunning { get { return _thread != null && _thread.IsAlive && _showHook != IntPtr.Zero && !_stop; } }

    public void Start(ConcurrentQueue<object> hits)
    {
        if (hits == null) throw new ArgumentNullException("hits");
        if (_thread != null) throw new InvalidOperationException("Window watcher already started.");
        _hits = hits;
        _selfPid = Process.GetCurrentProcess().Id;
        _error = "";
        _stop = false;
        _ready.Reset();
        _thread = new Thread(Run);
        _thread.Name = "CMD Flash Detector Window Events";
        _thread.IsBackground = true;
        _thread.SetApartmentState(ApartmentState.STA);
        _thread.Start();
        if (!_ready.Wait(4000))
        {
            Stop();
            throw new TimeoutException("SetWinEventHook startup timed out.");
        }
        if (_showHook == IntPtr.Zero || _foregroundHook == IntPtr.Zero || _createHook == IntPtr.Zero)
        {
            string reason = _error;
            Stop();
            throw new Win32Exception("Window event hook failed: " + reason);
        }
    }

    private void Run()
    {
        try
        {
            _threadId = GetCurrentThreadId();
            MSG message;
            PeekMessage(out message, IntPtr.Zero, 0, 0, 0); // create a thread message queue
            _callback = OnWindowEvent;
            _callbackRoot = GCHandle.Alloc(_callback);
            _showHook = SetWinEventHook(EVENT_OBJECT_SHOW, EVENT_OBJECT_HIDE,
                IntPtr.Zero, _callback, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
            if (_showHook == IntPtr.Zero)
                throw new Win32Exception(Marshal.GetLastWin32Error(), "SetWinEventHook object show/hide");
            _createHook = SetWinEventHook(EVENT_OBJECT_CREATE, EVENT_OBJECT_DESTROY,
                IntPtr.Zero, _callback, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
            if (_createHook == IntPtr.Zero)
                throw new Win32Exception(Marshal.GetLastWin32Error(), "SetWinEventHook object create/destroy");
            _foregroundHook = SetWinEventHook(EVENT_SYSTEM_FOREGROUND, EVENT_SYSTEM_FOREGROUND,
                IntPtr.Zero, _callback, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
            if (_foregroundHook == IntPtr.Zero)
                throw new Win32Exception(Marshal.GetLastWin32Error(), "SetWinEventHook foreground");
            _ready.Set();
            int result;
            while (!_stop && (result = GetMessage(out message, IntPtr.Zero, 0, 0)) > 0)
            {
                TranslateMessage(ref message);
                DispatchMessage(ref message);
            }
        }
        catch (Exception ex)
        {
            _error = ex.GetType().Name + ": " + ex.Message;
            _ready.Set();
        }
        finally
        {
            if (_createHook != IntPtr.Zero) { UnhookWinEvent(_createHook); _createHook = IntPtr.Zero; }
            if (_foregroundHook != IntPtr.Zero) { UnhookWinEvent(_foregroundHook); _foregroundHook = IntPtr.Zero; }
            if (_showHook != IntPtr.Zero) { UnhookWinEvent(_showHook); _showHook = IntPtr.Zero; }
            _threadId = 0;
            if (_callbackRoot.IsAllocated) _callbackRoot.Free();
            _ready.Set();
        }
    }

    private static string ClassOf(IntPtr hwnd)
    {
        var buf = new StringBuilder(256);
        return GetClassName(hwnd, buf, buf.Capacity) > 0 ? buf.ToString() : "";
    }
    private static string TitleOf(IntPtr hwnd)
    {
        var buf = new StringBuilder(1024);
        return GetWindowText(hwnd, buf, buf.Capacity) > 0 ? buf.ToString() : "";
    }
    private static void GetProcessInfo(int pid, out string path, out int parentPid)
    {
        path = "";
        parentPid = 0;
        if (pid <= 0) return;
        IntPtr handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, (uint)pid);
        if (handle == IntPtr.Zero) return;
        try
        {
            var buf = new StringBuilder(32768);
            int length = buf.Capacity;
            if (QueryFullProcessImageName(handle, 0, buf, ref length)) path = buf.ToString();
            var basic = new PROCESS_BASIC_INFORMATION();
            int returned;
            if (NtQueryInformationProcess(handle, 0, ref basic, Marshal.SizeOf(typeof(PROCESS_BASIC_INFORMATION)), out returned) == 0)
            {
                long parent = basic.InheritedFromUniqueProcessId.ToInt64();
                if (parent > 0 && parent <= int.MaxValue) parentPid = (int)parent;
            }
        }
        catch { /* optional details may be inaccessible */ }
        finally { CloseHandle(handle); }
    }
    private static string QueryPath(int pid)
    {
        if (pid <= 0) return "";
        IntPtr h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, (uint)pid);
        if (h == IntPtr.Zero) return "";
        try
        {
            var sb = new StringBuilder(32768);
            int n = sb.Capacity;
            return QueryFullProcessImageName(h, 0, sb, ref n) ? sb.ToString() : "";
        }
        finally { CloseHandle(h); }
    }
    private static string ProcessName(int pid, string path)
    {
        if (!String.IsNullOrEmpty(path)) return Path.GetFileName(path);
        try { using (var p = Process.GetProcessById(pid)) { return p.ProcessName + ".exe"; } }
        catch { return "(프로세스 종료/접근 불가)"; }
    }
    private void OnWindowEvent(IntPtr hook, uint ev, IntPtr hwnd, int idObject,
        int idChild, uint eventThread, uint eventTime)
    {
        try
        {
            if (_stop || hwnd == IntPtr.Zero || idObject != OBJID_WINDOW || idChild != 0) return;
            long handle = hwnd.ToInt64();
            DateTime now = DateTime.Now;
            if (ev == EVENT_OBJECT_HIDE || ev == EVENT_OBJECT_DESTROY)
            {
                VisibleWindow old;
                if (!_windows.TryGetValue(handle, out old)) return;
                _windows.Remove(handle);
                var original = old.Record;
                string hideTitle = TitleOf(hwnd);
                var hide = new FlashWindowEvent {
                    Time = now, Source = "창 숨김", Name = original.Name, ProcId = original.ProcId,
                    ParentId = original.ParentId, Path = original.Path, Command = "",
                    ParentPath = original.ParentPath, ParentCommand = "", TaskName = "",
                    WindowTitle = String.IsNullOrEmpty(original.WindowTitle) ? hideTitle : original.WindowTitle, WindowClass = original.WindowClass,
                    WindowHandle = handle, WindowAction = "HIDE",
                    WindowDurationMs = Math.Max(0, (int)Math.Min(int.MaxValue, (now - old.Time).TotalMilliseconds))
                };
                _hits.Enqueue(hide);
                Interlocked.Increment(ref _hideCount);
                return;
            }
            // A destroyed HWND may no longer have a valid ancestor; check ancestry only for creation/show.
            if (GetAncestor(hwnd, GA_ROOT) != hwnd) return;
            if (ev != EVENT_OBJECT_CREATE && ev != EVENT_OBJECT_SHOW && ev != EVENT_SYSTEM_FOREGROUND) return;
            if (ev == EVENT_OBJECT_CREATE)
            {
                // Top-level creation is *not* evidence of a visible window.
                // Restrict pre-show capture to identified console windows.
                string cls = ClassOf(hwnd);
                if (!cls.Equals("ConsoleWindowClass", StringComparison.OrdinalIgnoreCase) &&
                    !cls.Equals("CASCADIA_HOSTING_WINDOW_CLASS", StringComparison.OrdinalIgnoreCase)) return;
            }
            if (ev == EVENT_SYSTEM_FOREGROUND && !IsWindowVisible(hwnd)) return;
            VisibleWindow known;
            if (_windows.TryGetValue(handle, out known))
            {
                // A console may be observed during CREATE, then becomes visible.
                if (ev != EVENT_OBJECT_CREATE && known.Record.WindowAction == "CREATE")
                {
                    known.Record.WindowAction = "SHOW";
                    var upgrade = new FlashWindowEvent {
                        Time = now, Source = "창 표시", Name = known.Record.Name,
                        ProcId = known.Record.ProcId, ParentId = known.Record.ParentId,
                        Path = known.Record.Path, ParentPath = known.Record.ParentPath,
                        WindowTitle = TitleOf(hwnd), WindowClass = known.Record.WindowClass,
                        WindowHandle = handle, WindowAction = "SHOW", WindowDurationMs = -1
                    };
                    _hits.Enqueue(upgrade);
                    Interlocked.Increment(ref _showCount);
                }
                return;
            } // SHOW+FOREGROUND dedupe
            uint rawPid;
            GetWindowThreadProcessId(hwnd, out rawPid);
            if (rawPid <= 0 || rawPid > int.MaxValue || rawPid == (uint)_selfPid) return;
            int pid = (int)rawPid;
            string path;
            int parentPid;
            GetProcessInfo(pid, out path, out parentPid);
            string name = ProcessName(pid, path);
            string parentPath = QueryPath(parentPid);
            var shown = new FlashWindowEvent {
                Time = now, Source = ev == EVENT_OBJECT_CREATE ? "창 생성(콘솔)" : "창 표시", Name = name, ProcId = pid, ParentId = parentPid,
                Path = path, Command = "", ParentPath = parentPath, ParentCommand = "", TaskName = "",
                WindowTitle = TitleOf(hwnd), WindowClass = ClassOf(hwnd), WindowHandle = handle,
                WindowAction = ev == EVENT_OBJECT_CREATE ? "CREATE" : "SHOW", WindowDurationMs = -1
            };
            _windows[handle] = new VisibleWindow { Time = now, Record = shown };
            _hits.Enqueue(shown);
            if (ev != EVENT_OBJECT_CREATE) Interlocked.Increment(ref _showCount);
            // Avoid keeping handles alive forever if an app never sends HIDE.
            if (_windows.Count > 2048)
            {
                var stale = new List<long>();
                foreach (var kv in _windows)
                    if ((now - kv.Value.Time).TotalHours > 1) stale.Add(kv.Key);
                foreach (long key in stale) _windows.Remove(key);
            }
        }
        catch (Exception ex)
        {
            _error = "Event callback: " + ex.GetType().Name + ": " + ex.Message;
        }
    }
    public void Stop()
    {
        _stop = true;
        uint tid = _threadId;
        if (tid != 0) PostThreadMessage(tid, WM_QUIT, IntPtr.Zero, IntPtr.Zero);
        Thread worker = _thread;
        if (worker != null && worker != Thread.CurrentThread) worker.Join(1500);
        _thread = null;
        if (worker == null || !worker.IsAlive) _windows.Clear();
    }
    public void Dispose() { Stop(); }
}

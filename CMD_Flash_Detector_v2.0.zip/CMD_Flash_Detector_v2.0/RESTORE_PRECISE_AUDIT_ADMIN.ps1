$ErrorActionPreference = 'Stop'
$guid = '{0CCE922B-69AE-11D9-BED3-505054503030}'
$key = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit'
$valueName = 'ProcessCreationIncludeCmdLine_Enabled'
$backup = Join-Path $env:LOCALAPPDATA 'CMD_Flash_Detector\PreciseAuditOriginal.json'
try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    if (-not ([Security.Principal.WindowsPrincipal]$identity).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Administrator rights are required.' }
    if (-not (Test-Path -LiteralPath $backup)) { throw "No saved original setting: $backup" }
    $data = Get-Content -LiteralPath $backup -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($data.Computer -ne $env:COMPUTERNAME) { throw 'Saved settings belong to a different PC.' }
    Write-Host 'This restores the recorded process audit SUCCESS policy and command-line setting.' -ForegroundColor Yellow
    Write-Host 'If Group Policy or another administrator changed the configuration since then, do not restore blindly.' -ForegroundColor Yellow
    $ok = Read-Host 'Type RESTORE to apply the original setting'
    if ($ok -ne 'RESTORE') { Write-Host 'Cancelled'; exit 0 }
    $mode = if ([bool]$data.OriginalSuccessEnabled) { 'enable' } else { 'disable' }
    $result = @( & auditpol.exe /set ('/subcategory:' + $guid) ('/success:' + $mode) 2>&1 )
    if ($LASTEXITCODE -ne 0) { throw "auditpol restore failed: $($result -join ' ')" }
    if ([bool]$data.OriginalCmdLinePresent) {
        if (-not (Test-Path -LiteralPath $key)) { New-Item -Path $key -Force | Out-Null }
        New-ItemProperty -Path $key -Name $valueName -Value ([int]$data.OriginalCmdLineValue) -PropertyType DWord -Force | Out-Null
    } elseif (Test-Path -LiteralPath $key) {
        Remove-ItemProperty -Path $key -Name $valueName -ErrorAction SilentlyContinue
    }
    Rename-Item -LiteralPath $backup -NewName ('PreciseAuditRestored_' + (Get-Date).ToString('yyyyMMdd_HHmmss') + '.json')
    Write-Host 'Restored original settings. Prior Security events are NOT deleted.' -ForegroundColor Green
} catch { Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
